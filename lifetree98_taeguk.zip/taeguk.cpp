//
// WinAPI�� �±ر� �׸���
// �ۼ���: �̱ռ� lifetree98@hotmail.com)
// ���� : �ʵ��б� ����, �ڿ� ���Ľ��� ������ �׷ȴ� �±رⰡ ��������
// �ѹ� ������GDI �Լ��� ������ â�� �±ر⸦ �׷��ý��ϴ�.  ����
//



#pragma warning(disable: 4244)


#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


#define PI (3.141592654F)

enum ENUM_COLOR
{
	ECOLOR_OLD,
	ECOLOR_RED,
	ECOLOR_BLUE,
	ECOLOR_BLACK,
	ECOLOR_WHITE,
	ECOLOR_MAX,
};

class Taegukki
{
public:
	float m_width;
	float m_height;
	float m_x, m_y;
	
	Taegukki()
	{
		Init();
	}
	
	Taegukki(int x, int y)
	{
		SetPos(x, y);
	}
	
	
	void Init()
	{
		SetPos(10, 10);
	}
	
	void SetPos(int x, int y)
	{
		m_x = (float)x;
		m_y = (float)y;
	}
	
	void SetColor(HDC hdc, int i_color)
	{
		static HBRUSH brush1, oldbrush;
		static HPEN pen1, oldpen;
		static int flag=0;
		
		switch(i_color)
		{
		case 1: // red color
			pen1 = ::CreatePen(PS_SOLID, 2, RGB(255, 0, 0));
			oldpen = (HPEN)::SelectObject(hdc, pen1);
			
			brush1 = ::CreateSolidBrush(RGB(255, 0, 0));
			oldbrush = (HBRUSH)::SelectObject(hdc, brush1);
			flag = 1;
			break;
			
		case 2: // blue color
			pen1 = ::CreatePen(PS_SOLID, 2, RGB(0, 0, 255));
			oldpen = (HPEN)::SelectObject(hdc, pen1);
			
			brush1 = ::CreateSolidBrush(RGB(0, 0, 255));
			oldbrush = (HBRUSH)::SelectObject(hdc, brush1);
			flag = 1;
			break;
			
		case 3: // black color
			pen1 = ::CreatePen(PS_SOLID, 2, RGB(0, 0, 0));
			oldpen = (HPEN)::SelectObject(hdc, pen1);
			
			brush1 = ::CreateSolidBrush(RGB(0, 0, 0));
			oldbrush = (HBRUSH)::SelectObject(hdc, brush1);
			flag = 1;
			break;
			
		case 4: // white color
			pen1 = ::CreatePen(PS_SOLID, 1, RGB(0, 0, 0));
			oldpen = (HPEN)::SelectObject(hdc, pen1);
			
			brush1 = ::CreateSolidBrush(RGB(255, 255, 255));
			oldbrush = (HBRUSH)::SelectObject(hdc, brush1);
			flag = 1;
			
			break;
			
		case 0: // old color
			if (flag == 1)
			{
				::SelectObject(hdc, oldbrush);
				::SelectObject(hdc, oldpen);
				
				::DeleteObject(pen1);
				::DeleteObject(brush1);
				flag = 0;
			}
			break;
		}
		
	}
	
	void DrawBox(HDC hdc, int i_width)
	{
		m_width = (float)i_width;
		m_width -= m_x*2.0f;
		m_height = m_width * (2.0f / 3.0f);
		
		// ��ü �׵θ� �簢��
		Rectangle(hdc, m_x, m_y, m_x+m_width, m_y+m_height);
		
		// ū��
		DrawCircle(hdc);
		
		// ���� �ݿ�
		DrawHalfCircle(hdc);
		
		// �ǰﰨ��
		DrawGae(hdc);
	}
	
	void DrawCircle(HDC hdc)
	{
		// ū���� ������
		float radius = m_height / 2.0f / 2.0f;
		
		// �߽� ��ǥ
		float x, y;
		x = m_width / 2.0f + m_x;
		y = m_height / 2.0f + m_y;
		
		float x1, y1, x2, y2;
		// ������ ���⺤��
		x1 = m_x - x;
		y1 = m_y - y;
		x2 = x1 / sqrt(x1*x1 + y1*y1);
		y2 = y1 / sqrt(x1*x1 + y1*y1);
		
		// �������� ū���� �ݿ�
		SetColor(hdc, ECOLOR_RED); 
		::Pie(hdc, 
			x-radius, y-radius, 
			x+radius, y+radius, 
			x - x2*radius, y - y2*radius, 
			x + x2*radius, y + y2*radius);
		SetColor(hdc, ECOLOR_OLD); 
		
		// ���ʾƷ� ū���� �ݿ�
		SetColor(hdc, ECOLOR_BLUE); 
		::Pie(hdc, 
			x-radius, y-radius, 
			x+radius, y+radius, 
			x + x2*radius, y + y2*radius, 
			x - x2*radius, y - y2*radius);
		SetColor(hdc, ECOLOR_OLD); 
	}
	
	void DrawHalfCircle(HDC hdc)
	{
		// ���� �ݿ��� ������
		float radius = m_height / 2.0f / 4.0f;
		
		float cx, cy;
		float x, y, x1, y1, x2, y2;
		cx = m_width / 2.0f + m_x;
		cy = m_height / 2.0f + m_y;
		// �������� ���⺤��
		x1 = m_x - cx;
		y1 = m_y - cy;
		x2 = x1 / sqrt(x1*x1 + y1*y1);
		y2 = y1 / sqrt(x1*x1 + y1*y1);
		
		// ���� ���� �ݿ�
		x = cx + x2 * radius + 1;
		y = cy + y2 * radius  - 1;
		
		SetColor(hdc, ECOLOR_RED); 
		::Pie(hdc, 
			x-radius, y-radius, 
			x+radius, y+radius, 
			x + x2*radius, y + y2*radius, 
			x - x2*radius, y - y2*radius);
		SetColor(hdc, ECOLOR_OLD); 
		
		// ������ ���� �ݿ�
		x = cx - x2 * radius;
		y = cy - y2 * radius;
		
		SetColor(hdc, ECOLOR_BLUE); 
		::Pie(hdc, 
			x-radius, y-radius, 
			x+radius, y+radius, 
			x - x2*radius, y - y2*radius, 
			x + x2*radius, y + y2*radius);
		SetColor(hdc, ECOLOR_OLD); 
		
		
		
		
	}
	
	void LineBox(HDC hdc, int* px, int *py)
	{
		SetColor(hdc, ECOLOR_BLACK);
		POINT point_array[5];
		int i;
		
		for (i=0; i<4; ++i)
		{
			point_array[i].x = px[i];
			point_array[i].y = py[i];
		}
		point_array[i].x = px[0];
		point_array[i].y = py[0];
		Polygon(hdc, point_array, 5);
		SetColor(hdc, ECOLOR_OLD);
		
		
	}
	
	void DrawGae(HDC hdc)
	{
		float radius = m_height / 2.0f;
		radius /= 4.0f;
		
		float cx, cy;
		float x, y, x1, y1;
		float x2, y2, x3, y3;
		float x21, y21, x31, y31;
		
		// �߽� ��ǥ
		cx = m_width / 2.0f + m_x;
		cy = m_height / 2.0f + m_y;
		//
		// 01 ���� ���� (������ ����)
		x1 = m_x - cx;
		y1 = m_y - cy;
		x2 = x1 / sqrt(x1*x1 + y1*y1);
		y2 = y1 / sqrt(x1*x1 + y1*y1);
		// 02 ���������� 90�� ȸ���� ���� ����
		x21 = -y2; //x2*cosf(PI/2.0f) - y2*sinf(PI/2.0f);
		y21 = x2; //x2*sinf(PI/2.0f) + y2*cosf(PI/2.0f);
		// 03 ���� ����  (�������� ����)
		x1 = m_x+m_width - cx;
		y1 = m_y - cy;
		x3 = x1 / sqrt(x1*x1 + y1*y1);
		y3 = y1 / sqrt(x1*x1 + y1*y1);
		// 04 ���������� 90�� ȸ���� ���� ����
		x31 = -y3; //x3*cosf(PI/2.0f) - y3*sinf(PI/2.0f);
		y31 = x3; //x3*sinf(PI/2.0f) + y3*cosf(PI/2.0f);
		//
		//
		
		int sx[4], sy[4];
		// �� : ������
		// lt 01 -- ��
		x = cx + x2 * radius * 3.0f;
		y = cy + y2 * radius * 3.0f;
		sx[0] = x+x21*radius;
		sy[0] = y+y21*radius;
		sx[1] = x-x21*radius;
		sy[1] = y-y21*radius;
		sx[2] = x-x21*radius+x2*radius/4.0f;
		sy[2] = y-y21*radius+y2*radius/4.0f;
		sx[3] = x-x21*radius+x2*radius/4.0f+x21*radius*2.0f;
		sy[3] = y-y21*radius+y2*radius/4.0f+y21*radius*2.0f;
		LineBox(hdc, sx, sy);
		// lt 02
		x = x + x2*radius/4.0f + x2*radius/4.0f/2.0f;
		y = y + y2*radius/4.0f + y2*radius/4.0f/2.0f;
		sx[0] = x+x21*radius;
		sy[0] = y+y21*radius;
		sx[1] = x-x21*radius;
		sy[1] = y-y21*radius;
		sx[2] = x-x21*radius+x2*radius/4.0f;
		sy[2] = y-y21*radius+y2*radius/4.0f;
		sx[3] = x-x21*radius+x2*radius/4.0f+x21*radius*2.0f;
		sy[3] = y-y21*radius+y2*radius/4.0f+y21*radius*2.0f;
		LineBox(hdc, sx, sy);
		// lt 03
		x = x + x2*radius/4.0f + x2*radius/4.0f/2.0f;
		y = y + y2*radius/4.0f + y2*radius/4.0f/2.0f;
		sx[0] = x+x21*radius;
		sy[0] = y+y21*radius;
		sx[1] = x-x21*radius;
		sy[1] = y-y21*radius;
		sx[2] = x-x21*radius+x2*radius/4.0f;
		sy[2] = y-y21*radius+y2*radius/4.0f;
		sx[3] = x-x21*radius+x2*radius/4.0f+x21*radius*2.0f;
		sy[3] = y-y21*radius+y2*radius/4.0f+y21*radius*2.0f;
		LineBox(hdc, sx, sy);
		
		// �� : �����ʾƷ�
		// rb 01-1 -- ��
		x = cx - x2 * radius * 3.0f;
		y = cy - y2 * radius * 3.0f;
		sx[0] = x+x21*radius;
		sy[0] = y+y21*radius;
		sx[1] = x+x21*radius-x2*radius/4.0f;
		sy[1] = y+y21*radius-y2*radius/4.0f;
		sx[2] = x+x21*radius-x2*radius/4.0f-x21*radius+x21*radius/4.0f/2.0f/2.0f;
		sy[2] = y+y21*radius-y2*radius/4.0f-y21*radius+y21*radius/4.0f/2.0f/2.0f;
		sx[3] = x+x21*radius-x2*radius/4.0f-x21*radius+x21*radius/4.0f/2.0f/2.0f+x2*radius/4.0f;
		sy[3] = y+y21*radius-y2*radius/4.0f-y21*radius+y21*radius/4.0f/2.0f/2.0f+y2*radius/4.0f;
		LineBox(hdc, sx, sy);
		// rb 01-2
		x = x - x21*radius -x21*radius/4.0f/2.0f/2.0f;
		y = y - y21*radius -y21*radius/4.0f/2.0f/2.0f;
		sx[0] = x+x21*radius;
		sy[0] = y+y21*radius;
		sx[1] = x+x21*radius-x2*radius/4.0f;
		sy[1] = y+y21*radius-y2*radius/4.0f;
		sx[2] = x+x21*radius-x2*radius/4.0f-x21*radius+x21*radius/4.0f/2.0f/2.0f;
		sy[2] = y+y21*radius-y2*radius/4.0f-y21*radius+y21*radius/4.0f/2.0f/2.0f;
		sx[3] = x+x21*radius-x2*radius/4.0f-x21*radius+x21*radius/4.0f/2.0f/2.0f+x2*radius/4.0f;
		sy[3] = y+y21*radius-y2*radius/4.0f-y21*radius+y21*radius/4.0f/2.0f/2.0f+y2*radius/4.0f;
		LineBox(hdc, sx, sy);
		// rb 02-1
		x = x + x21*radius +x21*radius/4.0f/2.0f/2.0f -x2*radius/4.0f -x2*radius/4.0f/2.0f;
		y = y + y21*radius +y21*radius/4.0f/2.0f/2.0f -y2*radius/4.0f -y2*radius/4.0f/2.0f;
		sx[0] = x+x21*radius;
		sy[0] = y+y21*radius;
		sx[1] = x+x21*radius-x2*radius/4.0f;
		sy[1] = y+y21*radius-y2*radius/4.0f;
		sx[2] = x+x21*radius-x2*radius/4.0f-x21*radius+x21*radius/4.0f/2.0f/2.0f;
		sy[2] = y+y21*radius-y2*radius/4.0f-y21*radius+y21*radius/4.0f/2.0f/2.0f;
		sx[3] = x+x21*radius-x2*radius/4.0f-x21*radius+x21*radius/4.0f/2.0f/2.0f+x2*radius/4.0f;
		sy[3] = y+y21*radius-y2*radius/4.0f-y21*radius+y21*radius/4.0f/2.0f/2.0f+y2*radius/4.0f;
		LineBox(hdc, sx, sy);
		// rb 02-2
		x = x - x21*radius - x21*radius/4.0f/2.0f/2.0f;
		y = y - y21*radius - y21*radius/4.0f/2.0f/2.0f;
		sx[0] = x+x21*radius;
		sy[0] = y+y21*radius;
		sx[1] = x+x21*radius-x2*radius/4.0f;
		sy[1] = y+y21*radius-y2*radius/4.0f;
		sx[2] = x+x21*radius-x2*radius/4.0f-x21*radius+x21*radius/4.0f/2.0f/2.0f;
		sy[2] = y+y21*radius-y2*radius/4.0f-y21*radius+y21*radius/4.0f/2.0f/2.0f;
		sx[3] = x+x21*radius-x2*radius/4.0f-x21*radius+x21*radius/4.0f/2.0f/2.0f+x2*radius/4.0f;
		sy[3] = y+y21*radius-y2*radius/4.0f-y21*radius+y21*radius/4.0f/2.0f/2.0f+y2*radius/4.0f;
		LineBox(hdc, sx, sy);
		// rb 03-1
		x = x + x21*radius +x21*radius/4.0f/2.0f/2.0f -x2*radius/4.0f -x2*radius/4.0f/2.0f;
		y = y + y21*radius +y21*radius/4.0f/2.0f/2.0f -y2*radius/4.0f -y2*radius/4.0f/2.0f;
		sx[0] = x+x21*radius;
		sy[0] = y+y21*radius;
		sx[1] = x+x21*radius-x2*radius/4.0f;
		sy[1] = y+y21*radius-y2*radius/4.0f;
		sx[2] = x+x21*radius-x2*radius/4.0f-x21*radius+x21*radius/4.0f/2.0f/2.0f;
		sy[2] = y+y21*radius-y2*radius/4.0f-y21*radius+y21*radius/4.0f/2.0f/2.0f;
		sx[3] = x+x21*radius-x2*radius/4.0f-x21*radius+x21*radius/4.0f/2.0f/2.0f+x2*radius/4.0f;
		sy[3] = y+y21*radius-y2*radius/4.0f-y21*radius+y21*radius/4.0f/2.0f/2.0f+y2*radius/4.0f;
		LineBox(hdc, sx, sy);
		// rb 03-2
		x = x - x21*radius -x21*radius/4.0f/2.0f/2.0f;
		y = y - y21*radius -y21*radius/4.0f/2.0f/2.0f;
		sx[0] = x+x21*radius;
		sy[0] = y+y21*radius;
		sx[1] = x+x21*radius-x2*radius/4.0f;
		sy[1] = y+y21*radius-y2*radius/4.0f;
		sx[2] = x+x21*radius-x2*radius/4.0f-x21*radius+x21*radius/4.0f/2.0f/2.0f;
		sy[2] = y+y21*radius-y2*radius/4.0f-y21*radius+y21*radius/4.0f/2.0f/2.0f;
		sx[3] = x+x21*radius-x2*radius/4.0f-x21*radius+x21*radius/4.0f/2.0f/2.0f+x2*radius/4.0f;
		sy[3] = y+y21*radius-y2*radius/4.0f-y21*radius+y21*radius/4.0f/2.0f/2.0f+y2*radius/4.0f;
		LineBox(hdc, sx, sy);
		
		
		// �� : ��������
		// rt 01-1 -- ��
		x = cx + x3 * radius * 3.0f;
		y = cy + y3 * radius * 3.0f;
		sx[0] = x+x31*radius;
		sy[0] = y+y31*radius;
		sx[1] = x+x31*radius/4.0f/2.0f/2.0f;
		sy[1] = y+y31*radius/4.0f/2.0f/2.0f;
		sx[2] = x+x31*radius/4.0f/2.0f/2.0f+x3*radius/4.0f;
		sy[2] = y+y31*radius/4.0f/2.0f/2.0f+y3*radius/4.0f;
		sx[3] = x+x3*radius/4.0f+x31*radius;
		sy[3] = y+y3*radius/4.0f+y31*radius;
		LineBox(hdc, sx, sy);
		// rt 01-2
		x = x - x31 * radius - x31*radius/4.0f/2.0f/2.0f;
		y = y - y31 * radius - y31*radius/4.0f/2.0f/2.0f;
		sx[0] = x+x31*radius;
		sy[0] = y+y31*radius;
		sx[1] = x+x31*radius/4.0f/2.0f/2.0f;
		sy[1] = y+y31*radius/4.0f/2.0f/2.0f;
		sx[2] = x+x31*radius/4.0f/2.0f/2.0f+x3*radius/4.0f;
		sy[2] = y+y31*radius/4.0f/2.0f/2.0f+y3*radius/4.0f;
		sx[3] = x+x3*radius/4.0f+x31*radius;
		sy[3] = y+y3*radius/4.0f+y31*radius;
		LineBox(hdc, sx, sy);
		// rt 03-1
		x = x + x31*radius + x31*radius/4.0f/2.0f/2.0f + x3*radius/4.0f*2.0f + x3*radius/4.0f/2.0f*2.0f;
		y = y + y31*radius + y31*radius/4.0f/2.0f/2.0f + y3*radius/4.0f*2.0f + y3*radius/4.0f/2.0f*2.0f;
		sx[0] = x+x31*radius;
		sy[0] = y+y31*radius;
		sx[1] = x+x31*radius/4.0f/2.0f/2.0f;
		sy[1] = y+y31*radius/4.0f/2.0f/2.0f;
		sx[2] = x+x31*radius/4.0f/2.0f/2.0f+x3*radius/4.0f;
		sy[2] = y+y31*radius/4.0f/2.0f/2.0f+y3*radius/4.0f;
		sx[3] = x+x3*radius/4.0f+x31*radius;
		sy[3] = y+y3*radius/4.0f+y31*radius;
		LineBox(hdc, sx, sy);
		// rt 03-2
		x = x - x31*radius - x31*radius/4.0f/2.0f/2.0f;
		y = y - y31*radius - y31*radius/4.0f/2.0f/2.0f;
		sx[0] = x+x31*radius;
		sy[0] = y+y31*radius;
		sx[1] = x+x31*radius/4.0f/2.0f/2.0f;
		sy[1] = y+y31*radius/4.0f/2.0f/2.0f;
		sx[2] = x+x31*radius/4.0f/2.0f/2.0f+x3*radius/4.0f;
		sy[2] = y+y31*radius/4.0f/2.0f/2.0f+y3*radius/4.0f;
		sx[3] = x+x3*radius/4.0f+x31*radius;
		sy[3] = y+y3*radius/4.0f+y31*radius;
		LineBox(hdc, sx, sy);
		// rt 02
		x = x - x3*radius/4.0f - x3*radius/4.0f/2.0f + x31*radius +x31*radius/4.0f/2.0f/2.0f;
		y = y - y3*radius/4.0f - y3*radius/4.0f/2.0f + y31*radius +y31*radius/4.0f/2.0f/2.0f;
		sx[0] = x+x31*radius;
		sy[0] = y+y31*radius;
		sx[1] = x-x31*radius;
		sy[1] = y-y31*radius;
		sx[2] = x-x31*radius+x3*radius/4.0f;
		sy[2] = y-y31*radius+y3*radius/4.0f;
		sx[3] = x+x3*radius/4.0f+x31*radius;
		sy[3] = y+y3*radius/4.0f+y31*radius;
		LineBox(hdc, sx, sy);
		
		// �� : ���ʾƷ�
		// lb 01-1 -- ��
		x = cx - x3 * radius * 3.0f;
		y = cy - y3 * radius * 3.0f;
		sx[0] = x+x31*radius;
		sy[0] = y+y31*radius;
		sx[1] = x+x31*radius -x3*radius/4.0f;
		sy[1] = y+y31*radius -y3*radius/4.0f;
		sx[2] = x -x31*radius -x3*radius/4.0f;
		sy[2] = y -y31*radius -y3*radius/4.0f;
		sx[3] = x -x31*radius;
		sy[3] = y -y31*radius;
		LineBox(hdc, sx, sy);
		// lb 03-1
		x = x - x3*radius/4.0f*2.0f - x3*radius/4.0f/2.0f*2.0f;
		y = y - y3*radius/4.0f*2.0f - y3*radius/4.0f/2.0f*2.0f;
		sx[0] = x+x31*radius;
		sy[0] = y+y31*radius;
		sx[1] = x+x31*radius -x3*radius/4.0f;
		sy[1] = y+y31*radius -y3*radius/4.0f;
		sx[2] = x -x31*radius -x3*radius/4.0f;
		sy[2] = y -y31*radius -y3*radius/4.0f;
		sx[3] = x -x31*radius;
		sy[3] = y -y31*radius;
		LineBox(hdc, sx, sy);
		// lb 02-1
		x = x + x3*radius/4.0f + x3*radius/4.0f/2.0f;
		y = y + y3*radius/4.0f + y3*radius/4.0f/2.0f;
		sx[0] = x+x31*radius;
		sy[0] = y+y31*radius;
		sx[1] = x+x31*radius -x3*radius/4.0f;
		sy[1] = y+y31*radius -y3*radius/4.0f;
		sx[2] = x -x3*radius/4.0f +x31*radius/4.0f/2.0f/2.0f;
		sy[2] = y -y3*radius/4.0f +y31*radius/4.0f/2.0f/2.0f;
		sx[3] = x +x31*radius/4.0f/2.0f/2.0f;
		sy[3] = y +x31*radius/4.0f/2.0f/2.0f;
		LineBox(hdc, sx, sy);
		// lb 02-1
		x = x -x31*radius -x31*radius/4.0f/2.0f/2.0f;
		y = y -y31*radius -y31*radius/4.0f/2.0f/2.0f;
		sx[0] = x+x31*radius;
		sy[0] = y+y31*radius;
		sx[1] = x+x31*radius -x3*radius/4.0f;
		sy[1] = y+y31*radius -y3*radius/4.0f;
		sx[2] = x -x3*radius/4.0f +x31*radius/4.0f/2.0f/2.0f;
		sy[2] = y -y3*radius/4.0f +y31*radius/4.0f/2.0f/2.0f;
		sx[3] = x +x31*radius/4.0f/2.0f/2.0f;
		sy[3] = y +x31*radius/4.0f/2.0f/2.0f;
		LineBox(hdc, sx, sy);
}


};



// �±ر� Ŭ���� ���� ����

Taegukki g_tae(10, 10);



//*****************************************

// ���� �ڵ�� Win32 �⺻ ������ �ڵ��Դϴ�.

//*****************************************

HINSTANCE	g_hInst = NULL;             // current instance
HWND		g_hWnd  = NULL;             // Window Handle
char		g_ClassName[]= "taeguk";    // Class Name
LRESULT CALLBACK MsgPrc(HWND,UINT,WPARAM,LPARAM);	// Message Procedure


int APIENTRY WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
	WNDCLASS wc={0};
	MSG msg	={NULL};

	g_hInst = (HINSTANCE)GetModuleHandle(NULL);
	
	wc.style       = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc = (WNDPROC)MsgPrc;
	wc.hInstance   = g_hInst;
	wc.hIcon       = LoadIcon(NULL, IDI_APPLICATION);
	wc.hCursor     = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
	wc.lpszClassName = g_ClassName;
	
	if( 0 == RegisterClass(&wc))
		return FALSE;

	g_hWnd = CreateWindow(g_ClassName, g_ClassName, WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, g_hInst, NULL);
	
	if(NULL == g_hWnd)
		return FALSE;


	ShowWindow(g_hWnd, SW_SHOW);
	UpdateWindow(g_hWnd);


	// Main message loop:
	while(WM_QUIT != msg.message)
	{
		if(GetMessage(&msg, NULL, 0, 0))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return msg.wParam;
}


//  FUNCTION: MsgPrc(HWND, unsigned, WORD, LONG)
//  PURPOSE:  Processes messages for the main window.
//  WM_PAINT - Paint the main window
//  WM_DESTROY - post a quit message and return

LRESULT CALLBACK MsgPrc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	PAINTSTRUCT ps;
	HDC hdc;
	
	if(WM_KEYUP == message) 
	{
		if (wParam == VK_ESCAPE)
			DestroyWindow(hWnd);
	}

	else if(WM_PAINT == message)
	{
		hdc = BeginPaint(hWnd, &ps);

		RECT rt;
		GetClientRect(hWnd, &rt);
		
		//*****************************************
		
		// ���� �±ر⸦ �׸��� ��ƾ�Դϴ�.
		
		//*****************************************
		
		g_tae.DrawBox(hdc, rt.right-rt.left);

		
		EndPaint(hWnd, &ps);
	}

	else if(WM_DESTROY == message)
		PostQuitMessage(0);
	else
		return DefWindowProc(hWnd, message, wParam, lParam);


	return 0;
}



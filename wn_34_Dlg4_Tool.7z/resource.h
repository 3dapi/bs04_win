//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by EftTool.rc
//
#define IDI_MAIN_ICON                   101
#define IDR_MAIN_ACCEL                  113
#define IDR_MENU                        114
#define IDD_IMGSRC                      115
#define IDB_BITMAP1                     116
#define IDC_TX                          1019
#define IDC_BUTTON1                     1020
#define IDM_EXIT                        40003
#define IDM_NEW                         40004
#define IDM_OPEN                        40005
#define IDM_SAVE                        40006
#define IDM_ABOUT                       40007
#define ID_COLOR_RED                    40008
#define ID_COLOR_GREEN                  40009
#define IDM_COLOR_BLUE                  40010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        117
#define _APS_NEXT_COMMAND_VALUE         40011
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif

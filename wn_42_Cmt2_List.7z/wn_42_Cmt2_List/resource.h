//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by McApi.rc
//
#define IDR_MENU1                       101
#define IDB_BITMAP1                     105
#define IDB_BITMAP2                     106
#define IDM_ICON                        4000
#define IDM_SMALLICON                   4001
#define IDM_LIST                        4002
#define IDM_REPORT                      4003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         4004
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

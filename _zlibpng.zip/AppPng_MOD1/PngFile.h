//
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _PNGFILE_H_
#define _PNGFILE_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>

BOOL PngFileOpenDlg (HWND hwnd, PTSTR pstrFileName, PTSTR pstrTitleName) ;

INT PngLoadImage(	png_byte**	pOut
				,	char*		sFileName
				,	int*		piWidth
				,	int*		piHeight
				,	int*		piChannels
				,	png_color*	pBkgColor);


#if defined(PNG_NO_STDIO)
static void png_read_data(png_structp png_ptr, png_bytep data, png_size_t length);
static void png_write_data(png_structp png_ptr, png_bytep data, png_size_t length);
static void png_flush(png_structp png_ptr);
#endif


#endif



//  vcPng.C -- Shows a PNG image


// Copyright 2000, Willem van Schaik.

// This code is released under the libpng license.
// For conditions of distribution and use, see the disclaimer
// and license in png.h



#ifdef NDEBUG
#pragma comment(lib, "../lib/zlib123.lib")
#pragma comment(lib, "../lib/png124.lib")
#else
#pragma comment(lib, "../lib/zlib123_.lib")
#pragma comment(lib, "../lib/png124_.lib")
#endif



// constants
#define MARGIN 8

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>

// application includes
#include "../include/png.h"

#include "resource.h"

#define	SAFE_FREE(p) { if(p) { free(p); (p) = NULL; } }


struct PNG_PIXEL
{
	BYTE*	pPixel;
	INT		nWidth;
	INT		nHeight;
	INT		nChannel;

	BYTE	BgColorR;
	BYTE	BgColorG;
	BYTE	BgColorB;

	PNG_PIXEL()
	{
		pPixel	= NULL;
		nWidth	= 0;
		nHeight	= 0;
		nChannel= 0;

		BgColorR= 0;
		BgColorG= 0;
		BgColorB= 0;
	}
};


BOOL PngFileOpenDlg(HWND hwnd, PTSTR pstrFileName, PTSTR pstrTitleName) ;
INT PngLoadImage(PNG_PIXEL*	pPngOut, char* sFileName);


#if defined(PNG_NO_STDIO)
static void png_read_data(png_structp png_ptr, png_bytep data, png_size_t length);
static void png_write_data(png_structp png_ptr, png_bytep data, png_size_t length);
static void png_flush(png_structp png_ptr);
#endif




char		szProgName[] = "vcPng";
HINSTANCE	m_hInst	= NULL;
HWND		m_hWnd = NULL;


// function prototypes
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
INT LoadImageFile(HWND hwnd, char* sFileName, PNG_PIXEL* pPngOut);
void DisplayImage(HWND hwnd, BYTE** ppOutDib, BYTE** ppDiData, int cxWinSize, int cyWinSize, PNG_PIXEL* pPngSrc);
void InitBitmap(BYTE* pDiData, int cxWinSize, int cyWinSize);
void FillBitmap(BYTE* pDiData, int cxWinSize, int cyWinSize, PNG_PIXEL* pPngSrc);








// MAIN routine
int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE, PSTR, int iCmdShow)
{
	HACCEL   hAccel;
	MSG      msg;
	WNDCLASS wndclass;

	m_hInst	= hInstance;

	wndclass.style         = CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc   = WndProc;
	wndclass.cbClsExtra    = 0;
	wndclass.cbWndExtra    = 0;
	wndclass.hInstance     = hInstance;
	wndclass.hIcon         = LoadIcon (NULL, IDC_ICON) ;
	wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW);
	wndclass.hbrBackground = (HBRUSH) GetStockObject (GRAY_BRUSH);
	wndclass.lpszMenuName  = szProgName;
	wndclass.lpszClassName = szProgName;

	if (!RegisterClass (&wndclass))
		return 0;


	RECT rc ={0,0, 800, 600};

	::AdjustWindowRect(&rc, WS_OVERLAPPEDWINDOW, TRUE);

	m_hWnd = CreateWindow (szProgName
						, szProgName
						, WS_OVERLAPPEDWINDOW
						, 10
						, 10
						, rc.right - rc.left
						, rc.bottom- rc.top
						, NULL
						, NULL
						, hInstance
						, NULL);


	ShowWindow (m_hWnd, iCmdShow);
	UpdateWindow (m_hWnd);


	hAccel = LoadAccelerators (hInstance, szProgName);

	while (GetMessage (&msg, NULL, 0, 0))
	{
		if (!TranslateAccelerator (m_hWnd, hAccel, &msg))
		{
			TranslateMessage (&msg);
			DispatchMessage (&msg);
		}
	}

	return msg.wParam;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static BITMAPINFOHEADER  *pbmih;

	static PNG_PIXEL PngSrc;
	static int	cxWinSize, cyWinSize;

	static BYTE	*pDib = NULL;
	static BYTE	*pDiData = NULL;

	char	szImgPathName [MAX_PATH]={0};
	char	szTitleName [MAX_PATH]={0};
	
	WPARAM	wParLo	= LOWORD(wParam);
	WPARAM	wParHI	= HIWORD(wParam);


	if(uMsg == WM_SIZE)
	{
		cxWinSize = LOWORD (lParam);
		cyWinSize = HIWORD (lParam);

		// invalidate the client area for later update
		InvalidateRect(hWnd, NULL, TRUE);

		// display the PNG into the DIBitmap
		DisplayImage(hWnd, &pDib, &pDiData, cxWinSize, cyWinSize, &PngSrc);

		return 0;
	}

	else if(uMsg == WM_COMMAND)
	{
		HMENU hMenu = GetMenu (hWnd);

		if(wParLo == IDM_FILE_OPEN)
		{
			// show the File Open dialog box
			if (!PngFileOpenDlg (hWnd, szImgPathName, szTitleName))
				return 0;

			// load the image from file
			if (FAILED(LoadImageFile (hWnd, szImgPathName, &PngSrc)))
				return 0;

			// invalidate the client area for later update
			InvalidateRect (hWnd, NULL, TRUE);

			// display the PNG into the DIBitmap
			DisplayImage(hWnd, &pDib, &pDiData, cxWinSize, cyWinSize, &PngSrc);

			return 0;
		}

	}

	else if(uMsg == WM_PAINT)
	{
		PAINTSTRUCT	ps;
		HDC			hdc = BeginPaint (hWnd, &ps);

		if (pDib)
			SetDIBitsToDevice (hdc, 0, 0, cxWinSize, cyWinSize, 0, 0, 0, cyWinSize, pDiData, (BITMAPINFO *) pDib, DIB_RGB_COLORS);

		EndPaint (hWnd, &ps);
		return 0;

	}// WM_PAINT

	else if(uMsg == WM_CLOSE || uMsg == WM_DESTROY)
	{
		if (PngSrc.pPixel)
		{
			free (	PngSrc.pPixel	);
			PngSrc.pPixel = NULL;
		}

		if(pDib)
		{
			free(pDib);
			pDib = NULL;
		}

		PostQuitMessage (0);
		return 0;

	} // WM_DESTROY


	return DefWindowProc (hWnd, uMsg, wParam, lParam);
}



INT LoadImageFile(HWND hwnd, char* sFileName, PNG_PIXEL* pPngOut)
{
	PNG_PIXEL	tpPng;

	// open the PNG input file
	if (!sFileName)
		return -1;

	if(FAILED(PngLoadImage(&tpPng, sFileName)))
	{
		MessageBox (hwnd, "loading the PNG image Failed", "Err", MB_ICONEXCLAMATION | MB_OK);
		return -1;
	}


	// if there's an existing PNG, free the memory
	SAFE_FREE(	pPngOut->pPixel	);

	*pPngOut = tpPng;


	char szTmp [MAX_PATH]={0};
	sprintf (szTmp, "vcPng - %s", strrchr(sFileName, '\\') + 1);
	SetWindowText (hwnd, szTmp);

	return 0;
}


void DisplayImage(HWND hwnd, BYTE** ppOutDib, BYTE** ppDiData, int cxWinSize, int cyWinSize, PNG_PIXEL* pPngSrc)
{
	BYTE*				pDib		= *ppOutDib;
	BYTE*				pDiData		= *ppDiData;
	BITMAPINFOHEADER*	pbmih		= NULL;

	WORD				wDIRowBytes = (WORD) ((3 * cxWinSize + 3L) >> 2) << 2; // allocate memory for the Device Independant bitmap


	if (pDib)
	{
		free (pDib);
		pDib = NULL;
	}

	pDib	= (BYTE *) malloc (sizeof(BITMAPINFOHEADER) + wDIRowBytes * cyWinSize);
	memset (pDib, 0, sizeof(BITMAPINFOHEADER));

	*ppOutDib	= pDib;

	// initialize the dib-structure
	pbmih = (BITMAPINFOHEADER *) pDib;
	pbmih->biSize		= sizeof(BITMAPINFOHEADER);
	pbmih->biWidth		= cxWinSize;
	pbmih->biHeight		= -((long) cyWinSize);
	pbmih->biPlanes		= 1;
	pbmih->biBitCount	= 24;
	pbmih->biCompression= 0;

	pDiData		= pDib + sizeof(BITMAPINFOHEADER);
	*ppDiData	= pDiData;


	// first fill bitmap with gray and image border
	InitBitmap (pDiData, cxWinSize, cyWinSize);


	// then fill bitmap with image
	FillBitmap (pDiData, cxWinSize, cyWinSize, pPngSrc);
}


void InitBitmap (BYTE *pDiData, int cxWinSize, int cyWinSize)
{
	BYTE *dst;
	int x, y, col;

	// initialize the background with gray

	dst = pDiData;
	for (y = 0; y < cyWinSize; y++)
	{
		col = 0;
		for (x = 0; x < cxWinSize; x++)
		{
			// fill with GRAY
			*dst++ = 127;
			*dst++ = 127;
			*dst++ = 127;
			col += 3;
		}
		// rows start on 4 byte boundaries
		while ((col % 4) != 0)
		{
			dst++;
			col++;
		}
	}

}


void FillBitmap(BYTE *pDiData, int cxWinSize, int cyWinSize, PNG_PIXEL* pPngSrc)
{
	BYTE *src, *dst;
	BYTE r, g, b, a;
	const int cDIChannels = 3;
	WORD wImgRowBytes;
	WORD wDIRowBytes;

	int cxImgPos, cyImgPos;
	int xImg, yImg;
	int xWin, yWin;

	if(NULL == pPngSrc->pPixel)
		return;


	// calculate the central position

	cxImgPos = (cxWinSize - pPngSrc->nWidth) / 2;
	cyImgPos = (cyWinSize - pPngSrc->nHeight) / 2;

	// check for image larger than window

	if (cxImgPos < MARGIN)
		cxImgPos = MARGIN;
	if (cyImgPos < MARGIN)
		cyImgPos = MARGIN;

	// calculate both row-bytes

	wImgRowBytes = pPngSrc->nChannel * pPngSrc->nWidth;
	wDIRowBytes = (WORD) ((cDIChannels * cxWinSize + 3L) >> 2) << 2;

	// copy image to screen

	for (yImg = 0, yWin = cyImgPos; yImg < pPngSrc->nHeight; yImg++, yWin++)
	{
		if (yWin >= cyWinSize - MARGIN)
			break;

		src = pPngSrc->pPixel + yImg * wImgRowBytes;
		dst = pDiData + yWin * wDIRowBytes + cxImgPos * cDIChannels;

		for (xImg = 0, xWin = cxImgPos; xImg < pPngSrc->nWidth; xImg++, xWin++)
		{
			if (xWin >= cxWinSize - MARGIN)
				break;
			r = *src++;
			g = *src++;
			b = *src++;
			*dst++ = b; /* note the reverse order */
			*dst++ = g;
			*dst++ = r;
			if (pPngSrc->nChannel == 4)
			{
				a = *src++;
			}
		}
	}

}


OPENFILENAME ofn;


BOOL PngFileOpenDlg (HWND hwnd, PTSTR sFileName, PTSTR sTitle)
{
	char szFilter[] =	"PNG Files (*.png)\0*.png\0";

	memset(&ofn, 0, sizeof(ofn));

	ofn.lStructSize       = sizeof(OPENFILENAME);
	ofn.hwndOwner         = hwnd;
	ofn.lpstrFilter       = szFilter;
	ofn.nMaxFile          = MAX_PATH;
	ofn.nMaxFileTitle     = MAX_PATH;
	ofn.lpstrDefExt       = "png";

	ofn.lpstrFile         = sFileName;
	ofn.lpstrFileTitle    = sTitle;
	ofn.Flags             = OFN_HIDEREADONLY;

	return GetOpenFileName (&ofn);
}


// PNG image handler functions

INT PngLoadImage(PNG_PIXEL*	pPngOut, char* sFileName)
{
	FILE*			fp;
	png_byte        pbSig[8];
	int             iBitDepth;
	int             iColorType;
	double          dGamma;
	png_color_16*	pBackground;
	png_uint_32		ulChannels;
	png_uint_32		ulRowBytes;
	png_byte*		pPixel		= NULL;
	png_byte**		ppbRowPointers = NULL;

	png_structp		png_ptr = NULL;
	png_infop		info_ptr = NULL;

	int i = 0;

	fp = fopen(sFileName, "rb");

	if (NULL == fp)
		return -1;


	// first check the eight byte PNG signature
	fread(pbSig, 1, 8, fp);

	if (!png_check_sig(pbSig, 8))
		goto LOAD_IMAGE_ERROR;

	// create the two png(-info) structures
	png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, (png_error_ptr)NULL, (png_error_ptr)NULL);

	if (!png_ptr)
		goto LOAD_IMAGE_ERROR;


	info_ptr = png_create_info_struct(png_ptr);

	if (!info_ptr)
		goto LOAD_IMAGE_ERROR;


	// initialize the png structure
#if !defined(PNG_NO_STDIO)
	png_init_io(png_ptr, fp);
#else
	png_set_read_fn(png_ptr, (png_voidp)fp, png_read_data);
#endif


	png_set_sig_bytes(png_ptr, 8);


	// read all PNG info up to image data
	png_read_info(png_ptr, info_ptr);

	// get width, height, bit-depth and color-type
	png_get_IHDR(png_ptr
		, info_ptr
		, (png_uint_32 *)&pPngOut->nWidth
		, (png_uint_32 *)&pPngOut->nHeight
		, &iBitDepth
		, &iColorType
		, NULL, NULL, NULL);

	// expand images of all color-type and bit-depth to 3x8 bit RGB images
	// let the library process things like alpha, transparency, background

	if (iBitDepth == 16)
		png_set_strip_16(png_ptr);
	
	if (iColorType == PNG_COLOR_TYPE_PALETTE)
		png_set_expand(png_ptr);
	
	if (iBitDepth < 8)
		png_set_expand(png_ptr);
	
	if (png_get_valid(png_ptr, info_ptr, PNG_INFO_tRNS))
		png_set_expand(png_ptr);

	if (iColorType == PNG_COLOR_TYPE_GRAY ||
		iColorType == PNG_COLOR_TYPE_GRAY_ALPHA)
		png_set_gray_to_rgb(png_ptr);

	// set the background color to draw transparent and alpha images over.
	if (png_get_bKGD(png_ptr, info_ptr, &pBackground))
	{
		png_set_background(png_ptr, pBackground, PNG_BACKGROUND_GAMMA_FILE, 1, 1.0);
		pPngOut->BgColorR	= (byte) pBackground->red;
		pPngOut->BgColorG	= (byte) pBackground->green;
		pPngOut->BgColorB	= (byte) pBackground->blue;
	}

	// if required set gamma conversion
	if (png_get_gAMA(png_ptr, info_ptr, &dGamma))
		png_set_gamma(png_ptr, (double) 2.2, dGamma);

	// after the transformations have been registered update info_ptr data
	png_read_update_info(png_ptr, info_ptr);

	// get again width, height and the new bit-depth and color-type
	png_get_IHDR(png_ptr
		, info_ptr
		, (png_uint_32 *)&pPngOut->nWidth
		, (png_uint_32 *)&pPngOut->nHeight
		, &iBitDepth
		, &iColorType
		, NULL, NULL, NULL);


	// row_bytes is the width x number of channels
	ulRowBytes = png_get_rowbytes(png_ptr, info_ptr);
	ulChannels = png_get_channels(png_ptr, info_ptr);


	// Setup Channel
	pPngOut->nChannel= ulChannels;


	// now we can allocate memory to store the image
	pPixel = (png_byte*)malloc(ulRowBytes * pPngOut->nHeight * sizeof(png_byte));

	if(NULL == pPixel)
		goto LOAD_IMAGE_ERROR;


	// and allocate memory for an array of row-pointers
	ppbRowPointers = (png_bytepp)malloc(pPngOut->nHeight * sizeof(png_bytep));

	if( NULL == ppbRowPointers)
		goto LOAD_IMAGE_ERROR;




	// set the individual row-pointers to point at the correct offsets
	for(i = 0; i < pPngOut->nHeight; i++)
		ppbRowPointers[i] = pPixel + i * ulRowBytes;

	
	// now we can go ahead and just read the whole image
	png_read_image(png_ptr, ppbRowPointers);

	// read the additional chunks in the PNG file (not really needed)
	png_read_end(png_ptr, NULL);

	// yepp, done
	fclose (fp);


	
	// and we're done
	SAFE_FREE(	ppbRowPointers	);

	// free
	png_destroy_read_struct(&png_ptr, &info_ptr, NULL);

	
	// Setup Output Data
	pPngOut->pPixel = pPixel;

	return 0;

LOAD_IMAGE_ERROR:
	
	fclose(fp);

	png_destroy_read_struct(&png_ptr, &info_ptr, NULL);
	SAFE_FREE(	ppbRowPointers	);

	return -1;
}




#ifdef PNG_NO_STDIO

static void png_read_data(png_structp png_ptr, png_bytep data, png_size_t length)
{
	png_size_t check;

	/* fread() returns 0 on error, so it is OK to store this in a png_size_t
	* instead of an int, which is what fread() actually returns.
	*/
	check = (png_size_t)fread(data, (png_size_t)1, length,
		(FILE *)png_ptr->io_ptr);

	if (check != length)
	{
		png_error(png_ptr, "Read Error");
	}
}

static void png_write_data(png_structp png_ptr, png_bytep data, png_size_t length)
{
	png_uint_32 check;

	check = fwrite(data, 1, length, (FILE *)(png_ptr->io_ptr));
	if (check != length)
	{
		png_error(png_ptr, "Write Error");
	}
}

static void png_flush(png_structp png_ptr)
{
	FILE *io_ptr;
	io_ptr = (FILE *)CVT_PTR((png_ptr->io_ptr));
	if (io_ptr != NULL)
		fflush(io_ptr);
}

#endif


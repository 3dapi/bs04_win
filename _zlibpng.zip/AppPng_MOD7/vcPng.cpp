
//  vcPng.C -- Shows a PNG image


// Copyright 2000, Willem van Schaik.

// This code is released under the libpng license.
// For conditions of distribution and use, see the disclaimer
// and license in png.h



#ifdef NDEBUG
#pragma comment(lib, "../lib/zlib123.lib")
#pragma comment(lib, "../lib/png124.lib")
#else
#pragma comment(lib, "../lib/zlib123_.lib")
#pragma comment(lib, "../lib/png124_.lib")
#endif



// constants
#define MARGIN 8

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <windows.h>

// application includes
#include "../include/png.h"

#include "resource.h"


#define	SAFE_FREE(p) { if(p) { free(p); (p) = NULL; } }


struct PNG_PIXEL
{
	BYTE*	pPixel;
	INT		nWidth;
	INT		nHeight;
	INT		nChannel;

	BYTE	BgColorR;
	BYTE	BgColorG;
	BYTE	BgColorB;

	PNG_PIXEL()
	{
		pPixel	= NULL;
		nWidth	= 0;
		nHeight	= 0;
		nChannel= 0;

		BgColorR= 0;
		BgColorG= 0;
		BgColorB= 0;
	}

	PNG_PIXEL(const PNG_PIXEL& r)
	{
		SAFE_FREE(	pPixel	);

		pPixel	= r.pPixel	;
		nWidth	= r.nWidth	;
		nHeight	= r.nHeight	;
		nChannel= r.nChannel;

		BgColorR= r.BgColorR;
		BgColorG= r.BgColorG;
		BgColorB= r.BgColorB;
	}

	PNG_PIXEL& operator=(const PNG_PIXEL& r)
	{
		SAFE_FREE(	pPixel	);

		pPixel	= r.pPixel	;
		nWidth	= r.nWidth	;
		nHeight	= r.nHeight	;
		nChannel= r.nChannel;

		BgColorR= r.BgColorR;
		BgColorG= r.BgColorG;
		BgColorB= r.BgColorB;

		return *this;
	}

	void Destroy()
	{
		SAFE_FREE(	pPixel	);
	}

	void SetPixelData(BYTE* _pxl)
	{
		SAFE_FREE(	pPixel	);
		pPixel	= _pxl;
	}


};


char		szProgName[] = "vcPng";
HINSTANCE	m_hInst	= NULL;
HWND		m_hWnd = NULL;


INT LoadPngFile(PNG_PIXEL*	pPngOut, char* sFileName);
INT LoadImageFile(HWND hwnd, char* sFileName, PNG_PIXEL* pPngOut);
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);



// MAIN routine
int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE, PSTR, int iCmdShow)
{
	HACCEL   hAccel;
	MSG      msg;
	WNDCLASS wndclass;

	m_hInst	= hInstance;

	wndclass.style         = CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc   = WndProc;
	wndclass.cbClsExtra    = 0;
	wndclass.cbWndExtra    = 0;
	wndclass.hInstance     = hInstance;
	wndclass.hIcon         = LoadIcon (NULL, IDC_ICON) ;
	wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW);
	wndclass.hbrBackground = (HBRUSH) GetStockObject (GRAY_BRUSH);
	wndclass.lpszMenuName  = szProgName;
	wndclass.lpszClassName = szProgName;

	if (!RegisterClass (&wndclass))
		return 0;


	RECT rc ={0,0, 800, 600};

	::AdjustWindowRect(&rc, WS_OVERLAPPEDWINDOW, TRUE);

	m_hWnd = CreateWindow (szProgName
						, szProgName
						, WS_OVERLAPPEDWINDOW
						, 10
						, 10
						, rc.right - rc.left
						, rc.bottom- rc.top
						, NULL
						, NULL
						, hInstance
						, NULL);


	ShowWindow (m_hWnd, iCmdShow);
	UpdateWindow (m_hWnd);


	hAccel = LoadAccelerators (hInstance, szProgName);

	while (GetMessage (&msg, NULL, 0, 0))
	{
		if (!TranslateAccelerator (m_hWnd, hAccel, &msg))
		{
			TranslateMessage (&msg);
			DispatchMessage (&msg);
		}
	}

	return msg.wParam;
}


PNG_PIXEL PngSrc;


LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if(uMsg == WM_COMMAND)
	{
		char	sPngFileName [MAX_PATH]={0};
		char	szTitleName [MAX_PATH]={0};

		WPARAM	wParLo	= LOWORD(wParam);
		WPARAM	wParHI	= HIWORD(wParam);

		HMENU hMenu = GetMenu (hWnd);

		if(wParLo == IDM_FILE_OPEN)
		{
			
			OPENFILENAME ofn={0};
			char szFilter[] =	"PNG Files (*.png)\0*.png\0";

			ofn.lStructSize       = sizeof(OPENFILENAME);
			ofn.hwndOwner         = hWnd;
			ofn.lpstrFilter       = szFilter;
			ofn.nMaxFile          = MAX_PATH;
			ofn.nMaxFileTitle     = MAX_PATH;
			ofn.lpstrDefExt       = "png";

			ofn.lpstrFile         = sPngFileName;
			ofn.lpstrFileTitle    = szTitleName;
			ofn.Flags             = OFN_HIDEREADONLY;

			if(GetOpenFileName (&ofn))
			{
				if(SUCCEEDED(LoadImageFile (hWnd, sPngFileName, &PngSrc)))
					InvalidateRect (hWnd, NULL, TRUE);
			}

			return 0;
		}

	}

	else if(uMsg == WM_PAINT)
	{
		BYTE*		pPixel	= (BYTE*)PngSrc.pPixel;

		PAINTSTRUCT	ps;
		HDC			hdc		= BeginPaint (hWnd, &ps);

		BITMAPINFO	Dib ={0};

		// ������ �̹����� ũ�⸦ 4�� ����� ���ϴ� ���� ������.
		// �� ����� ���� ����...
		long	nWidth = ((3 * PngSrc.nWidth + 3L) >> 2) << 2;
		nWidth	/=3;

		Dib.bmiHeader.biSize		= sizeof(BITMAPINFOHEADER);
		Dib.bmiHeader.biWidth		= nWidth;
		Dib.bmiHeader.biHeight		= -((long) PngSrc.nHeight);
		Dib.bmiHeader.biPlanes		= 1;
		Dib.bmiHeader.biBitCount	= 24;

		if (PngSrc.pPixel)
		{
			SetDIBitsToDevice (hdc, 0, 0, PngSrc.nWidth, PngSrc.nHeight, 0, 0, 0, PngSrc.nHeight, pPixel, &Dib, DIB_RGB_COLORS);

			StretchDIBits(
				hdc						// handle to DC
				, PngSrc.nWidth/2		// x-coord of destination upper-left corner
				, PngSrc.nHeight/3		// y-coord of destination upper-left corner		
				, PngSrc.nWidth*4		// width of destination rectangle
				, PngSrc.nHeight*4		// height of destination rectangle
				, 0						// x-coord of source upper-left corner	
				, 0						// y-coord of source upper-left corner	
				, PngSrc.nWidth			// width of source rectangle
				, PngSrc.nHeight		// height of source rectangle
				, pPixel				// bitmap bits
				, (BITMAPINFO*)&Dib		// bitmap data
				, DIB_RGB_COLORS		// usage options
				, SRCCOPY				// raster operation code
				);
		}

		EndPaint (hWnd, &ps);
		return 0;

	}// WM_PAINT

	else if(uMsg == WM_CLOSE || uMsg == WM_DESTROY)
	{
		if (PngSrc.pPixel)
		{
			free (	PngSrc.pPixel	);
			PngSrc.pPixel = NULL;
		}

		PostQuitMessage (0);
		return 0;

	} // WM_DESTROY


	return DefWindowProc (hWnd, uMsg, wParam, lParam);
}



INT LoadImageFile(HWND hwnd, char* sFileName, PNG_PIXEL* pPngOut)
{
	PNG_PIXEL	tpPng;

	INT		nSizePxl;
	INT		n;

	BYTE*	pSrc;
	BYTE*	pDst;

	// open the PNG input file
	if (!sFileName)
		return -1;

	if(FAILED(LoadPngFile(&tpPng, sFileName)))
	{
		MessageBox (hwnd, "loading the PNG image Failed", "Err", MB_ICONEXCLAMATION | MB_OK);
		return -1;
	}


	nSizePxl = tpPng.nWidth * tpPng.nHeight;

	pDst = (BYTE*)malloc(nSizePxl * 3);
	pSrc = (BYTE*)tpPng.pPixel;

	// for 32 or 24 bit
	// R,G, B to B, G, R
	// PNG Order: r, g, b, a
	// Window, B, G, R
	for(n = 0; n < nSizePxl; ++n)
	{
		int idx1 =  n * 3;
		int idx2 =  n * tpPng.nChannel;

		pDst[idx1+0] = pSrc[idx2 + 2];
		pDst[idx1+1] = pSrc[idx2 + 1];
		pDst[idx1+2] = pSrc[idx2 + 0];
	}


	WORD wDIRowBytes = (WORD) ((tpPng.nChannel * tpPng.nWidth + 3L) >> 2) << 2;


	// Copy Infomation and Pixel.
	*pPngOut = tpPng;
	pPngOut->Destroy();
	pPngOut->SetPixelData(pDst);


	char szTmp [MAX_PATH]={0};
	sprintf (szTmp, "vcPng - %s", strrchr(sFileName, '\\') + 1);
	SetWindowText (hwnd, szTmp);

	return 0;
}



// PNG image handler functions

INT LoadPngFile(PNG_PIXEL*	pPngOut, char* sFileName)
{
	FILE*			fp;
	png_byte        pbSig[8];
	int             iBitDepth;
	int             iColorType;
	double          dGamma;
	png_color_16*	pBackground;
	png_uint_32		ulChannels;
	png_uint_32		ulRowBytes;
	png_byte*		pPixel		= NULL;
	png_byte**		ppbRowPointers = NULL;

	png_structp		png_ptr = NULL;
	png_infop		info_ptr = NULL;

	int i = 0;

	fp = fopen(sFileName, "rb");

	if (NULL == fp)
		return -1;


	// first check the eight byte PNG signature
	fread(pbSig, 1, 8, fp);

	if (!png_check_sig(pbSig, 8))
		goto LOAD_IMAGE_ERROR;

	// create the two png(-info) structures
	png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, (png_error_ptr)NULL, (png_error_ptr)NULL);

	if (!png_ptr)
		goto LOAD_IMAGE_ERROR;


	info_ptr = png_create_info_struct(png_ptr);

	if (!info_ptr)
		goto LOAD_IMAGE_ERROR;


	// initialize the png structure
	png_set_read_fn(png_ptr, (png_voidp)fp, NULL);



	png_set_sig_bytes(png_ptr, 8);


	// read all PNG info up to image data
	png_read_info(png_ptr, info_ptr);

	// get width, height, bit-depth and color-type
	png_get_IHDR(png_ptr
		, info_ptr
		, (png_uint_32 *)&pPngOut->nWidth
		, (png_uint_32 *)&pPngOut->nHeight
		, &iBitDepth
		, &iColorType
		, NULL, NULL, NULL);

	// expand images of all color-type and bit-depth to 3x8 bit RGB images
	// let the library process things like alpha, transparency, background

	if (iBitDepth == 16)
		png_set_strip_16(png_ptr);
	
	if (iColorType == PNG_COLOR_TYPE_PALETTE)
		png_set_expand(png_ptr);
	
	if (iBitDepth < 8)
		png_set_expand(png_ptr);
	
	if (png_get_valid(png_ptr, info_ptr, PNG_INFO_tRNS))
		png_set_expand(png_ptr);

	if (iColorType == PNG_COLOR_TYPE_GRAY ||
		iColorType == PNG_COLOR_TYPE_GRAY_ALPHA)
		png_set_gray_to_rgb(png_ptr);

	// set the background color to draw transparent and alpha images over.
	if (png_get_bKGD(png_ptr, info_ptr, &pBackground))
	{
		png_set_background(png_ptr, pBackground, PNG_BACKGROUND_GAMMA_FILE, 1, 1.0);
		pPngOut->BgColorR	= (byte) pBackground->red;
		pPngOut->BgColorG	= (byte) pBackground->green;
		pPngOut->BgColorB	= (byte) pBackground->blue;
	}

	// if required set gamma conversion
	if (png_get_gAMA(png_ptr, info_ptr, &dGamma))
		png_set_gamma(png_ptr, (double) 2.2, dGamma);

	// after the transformations have been registered update info_ptr data
	png_read_update_info(png_ptr, info_ptr);

	// get again width, height and the new bit-depth and color-type
	png_get_IHDR(png_ptr
		, info_ptr
		, (png_uint_32 *)&pPngOut->nWidth
		, (png_uint_32 *)&pPngOut->nHeight
		, &iBitDepth
		, &iColorType
		, NULL, NULL, NULL);


	// row_bytes is the width x number of channels
	ulRowBytes = png_get_rowbytes(png_ptr, info_ptr);
	ulChannels = png_get_channels(png_ptr, info_ptr);


	// Setup Channel
	pPngOut->nChannel= ulChannels;


	// now we can allocate memory to store the image
	pPixel = (png_byte*)malloc(ulRowBytes * pPngOut->nHeight * sizeof(png_byte));

	if(NULL == pPixel)
		goto LOAD_IMAGE_ERROR;


	// and allocate memory for an array of row-pointers
	ppbRowPointers = (png_bytepp)malloc(pPngOut->nHeight * sizeof(png_bytep));

	if( NULL == ppbRowPointers)
		goto LOAD_IMAGE_ERROR;




	// set the individual row-pointers to point at the correct offsets
	for(i = 0; i < pPngOut->nHeight; i++)
		ppbRowPointers[i] = pPixel + i * ulRowBytes;

	
	// now we can go ahead and just read the whole image
	png_read_image(png_ptr, ppbRowPointers);

	// read the additional chunks in the PNG file (not really needed)
	png_read_end(png_ptr, NULL);

	// yepp, done
	fclose (fp);


	
	// and we're done
	SAFE_FREE(	ppbRowPointers	);

	// free
	png_destroy_read_struct(&png_ptr, &info_ptr, NULL);

	
	// Setup Output Data
	pPngOut->pPixel = pPixel;

	return 0;

LOAD_IMAGE_ERROR:
	
	fclose(fp);

	png_destroy_read_struct(&png_ptr, &info_ptr, NULL);
	SAFE_FREE(	ppbRowPointers	);

	return -1;
}



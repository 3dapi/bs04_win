//
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _PNGFILE_H_
#define _PNGFILE_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>


#define	SAFE_FREE(p) { if(p) { free(p); (p) = NULL; } }


struct PNG_PIXEL
{
	BYTE*	pPixel;
	INT		nWidth;
	INT		nHeight;
	INT		nChannel;

	BYTE	BgColorR;
	BYTE	BgColorG;
	BYTE	BgColorB;

	PNG_PIXEL()
	{
		pPixel	= NULL;
		nWidth	= 0;
		nHeight	= 0;
		nChannel= 0;

		BgColorR= 0;
		BgColorG= 0;
		BgColorB= 0;
	}
};


BOOL PngFileOpenDlg (HWND hwnd, PTSTR pstrFileName, PTSTR pstrTitleName) ;

INT PngLoadImage(PNG_PIXEL*	pPngOut, char* sFileName);


#if defined(PNG_NO_STDIO)
static void png_read_data(png_structp png_ptr, png_bytep data, png_size_t length);
static void png_write_data(png_structp png_ptr, png_bytep data, png_size_t length);
static void png_flush(png_structp png_ptr);
#endif


#endif


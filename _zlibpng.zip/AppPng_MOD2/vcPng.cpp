
//  vcPng.C -- Shows a PNG image


// Copyright 2000, Willem van Schaik.

// This code is released under the libpng license.
// For conditions of distribution and use, see the disclaimer
// and license in png.h



#ifdef NDEBUG
#pragma comment(lib, "../lib/zlib123.lib")
#pragma comment(lib, "../lib/png124.lib")
#else
#pragma comment(lib, "../lib/zlib123_.lib")
#pragma comment(lib, "../lib/png124_.lib")
#endif


// constants
#define MARGIN 8

// standard includes
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>

// application includes
#include "../include/png.h"

#include "pngfile.h"
#include "resource.h"


char		szProgName[] = "vcPng";
HINSTANCE	m_hInst	= NULL;
HWND		m_hWnd = NULL;


// function prototypes
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);


INT LoadImageFile(HWND hwnd, char* sFileName, PNG_PIXEL* pPngOut);

void DisplayImage(HWND hwnd, BYTE** ppOutDib, BYTE** ppDiData, int cxWinSize, int cyWinSize, PNG_PIXEL* pPngSrc, BOOL bStretched);
void InitBitmap(BYTE* pDiData, int cxWinSize, int cyWinSize);
void FillBitmap(BYTE* pDiData, int cxWinSize, int cyWinSize, PNG_PIXEL* pPngSrc, BOOL bStretched);


// MAIN routine
int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE, PSTR, int iCmdShow)
{
	HACCEL   hAccel;
	MSG      msg;
	WNDCLASS wndclass;
	int ixBorders;
	int iyBorders;



	m_hInst	= hInstance;

	wndclass.style         = CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc   = WndProc;
	wndclass.cbClsExtra    = 0;
	wndclass.cbWndExtra    = 0;
	wndclass.hInstance     = hInstance;
	wndclass.hIcon         = LoadIcon (NULL, IDC_ICON) ;
	wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW);
	wndclass.hbrBackground = NULL; // (HBRUSH) GetStockObject (GRAY_BRUSH);
	wndclass.lpszMenuName  = szProgName;
	wndclass.lpszClassName = szProgName;

	if (!RegisterClass (&wndclass))
		return 0;



	// calculate size of window-borders
	ixBorders = 2 * (GetSystemMetrics (SM_CXBORDER) + GetSystemMetrics (SM_CXDLGFRAME));
	iyBorders = 2 * (GetSystemMetrics (SM_CYBORDER) + GetSystemMetrics (SM_CYDLGFRAME)) +
					GetSystemMetrics (SM_CYCAPTION) + GetSystemMetrics (SM_CYMENUSIZE) + 1; /* WvS: don't ask me why? */

	m_hWnd = CreateWindow (szProgName
						, szProgName
						, WS_OVERLAPPEDWINDOW
						, 10
						, 10
						, 810
						, 640
						, NULL
						, NULL
						, hInstance
						, NULL);


	ShowWindow (m_hWnd, iCmdShow);
	UpdateWindow (m_hWnd);


	hAccel = LoadAccelerators (hInstance, szProgName);

	while (GetMessage (&msg, NULL, 0, 0))
	{
		if (!TranslateAccelerator (m_hWnd, hAccel, &msg))
		{
			TranslateMessage (&msg);
			DispatchMessage (&msg);
		}
	}

	return msg.wParam;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static BITMAPINFOHEADER  *pbmih;

	static PNG_PIXEL PngSrc;
	static int	cxWinSize, cyWinSize;
	static BOOL bStretched = TRUE;

	static BYTE	*pDib = NULL;
	static BYTE	*pDiData = NULL;

	char	szImgPathName [MAX_PATH]={0};
	char	szTitleName [MAX_PATH]={0};
	
	WPARAM	wParLo	= LOWORD(wParam);
	WPARAM	wParHI	= HIWORD(wParam);


	if(uMsg == WM_SIZE)
	{
		cxWinSize = LOWORD (lParam);
		cyWinSize = HIWORD (lParam);

		// invalidate the client area for later update
		InvalidateRect(hWnd, NULL, TRUE);

		// display the PNG into the DIBitmap
		DisplayImage(hWnd, &pDib, &pDiData, cxWinSize, cyWinSize, &PngSrc, bStretched);

		return 0;
	}

	else if(uMsg == WM_COMMAND)
	{
		HMENU hMenu = GetMenu (hWnd);

		if(wParLo == IDM_FILE_OPEN)
		{
			// show the File Open dialog box
			if (!PngFileOpenDlg (hWnd, szImgPathName, szTitleName))
				return 0;

			// load the image from file
			if (FAILED(LoadImageFile (hWnd, szImgPathName, &PngSrc)))
				return 0;

			// invalidate the client area for later update
			InvalidateRect (hWnd, NULL, TRUE);

			// display the PNG into the DIBitmap
			DisplayImage(hWnd, &pDib, &pDiData, cxWinSize, cyWinSize, &PngSrc, bStretched);

			return 0;
		}

		else if(wParLo == IDM_OPTIONS_STRETCH)
		{
			bStretched = !bStretched;
			if (bStretched)
				CheckMenuItem (hMenu, IDM_OPTIONS_STRETCH, MF_CHECKED);
			else
				CheckMenuItem (hMenu, IDM_OPTIONS_STRETCH, MF_UNCHECKED);

			// invalidate the client area for later update
			InvalidateRect (hWnd, NULL, TRUE);

			// display the PNG into the DIBitmap
			DisplayImage(hWnd, &pDib, &pDiData, cxWinSize, cyWinSize, &PngSrc, bStretched);

			return 0;
		}

	}// WM_COMMAND

	else if(uMsg == WM_PAINT)
	{
		PAINTSTRUCT	ps;
		HDC			hdc = BeginPaint (hWnd, &ps);

		if (pDib)
			SetDIBitsToDevice (hdc, 0, 0, cxWinSize, cyWinSize, 0, 0, 0, cyWinSize, pDiData, (BITMAPINFO *) pDib, DIB_RGB_COLORS);

		EndPaint (hWnd, &ps);
		return 0;

	}// WM_PAINT

	else if(uMsg == WM_CLOSE || uMsg == WM_DESTROY)
	{
		if (PngSrc.pPixel)
		{
			free (	PngSrc.pPixel	);
			PngSrc.pPixel = NULL;
		}

		if(pDib)
		{
			free(pDib);
			pDib = NULL;
		}

		PostQuitMessage (0);
		return 0;

	} // WM_DESTROY


	return DefWindowProc (hWnd, uMsg, wParam, lParam);
}



INT LoadImageFile(HWND hwnd, char* sFileName, PNG_PIXEL* pPngOut)
{
	PNG_PIXEL	tpPng;

	// open the PNG input file
	if (!sFileName)
		return -1;

	if(FAILED(PngLoadImage(&tpPng, sFileName)))
	{
		MessageBox (hwnd, "loading the PNG image Failed", "Err", MB_ICONEXCLAMATION | MB_OK);
		return -1;
	}


	// if there's an existing PNG, free the memory
	SAFE_FREE(	pPngOut->pPixel	);

	*pPngOut = tpPng;


	char szTmp [MAX_PATH]={0};
	sprintf (szTmp, "vcPng - %s", strrchr(sFileName, '\\') + 1);
	SetWindowText (hwnd, szTmp);

	return 0;
}


void DisplayImage(HWND hwnd, BYTE** ppOutDib, BYTE** ppDiData, int cxWinSize, int cyWinSize, PNG_PIXEL* pPngSrc, BOOL bStretched)
{
	BYTE*				pDib		= *ppOutDib;
	BYTE*				pDiData		= *ppDiData;
	BITMAPINFOHEADER*	pbmih		= NULL;

	WORD				wDIRowBytes = (WORD) ((3 * cxWinSize + 3L) >> 2) << 2; // allocate memory for the Device Independant bitmap


	if (pDib)
	{
		free (pDib);
		pDib = NULL;
	}

	pDib	= (BYTE *) malloc (sizeof(BITMAPINFOHEADER) + wDIRowBytes * cyWinSize);
	memset (pDib, 0, sizeof(BITMAPINFOHEADER));

	*ppOutDib	= pDib;

	// initialize the dib-structure
	pbmih = (BITMAPINFOHEADER *) pDib;
	pbmih->biSize		= sizeof(BITMAPINFOHEADER);
	pbmih->biWidth		= cxWinSize;
	pbmih->biHeight		= -((long) cyWinSize);
	pbmih->biPlanes		= 1;
	pbmih->biBitCount	= 24;
	pbmih->biCompression= 0;

	pDiData		= pDib + sizeof(BITMAPINFOHEADER);
	*ppDiData	= pDiData;


	// first fill bitmap with gray and image border
	InitBitmap (pDiData, cxWinSize, cyWinSize);


	// then fill bitmap with image
	FillBitmap (pDiData, cxWinSize, cyWinSize, pPngSrc, bStretched);
}


void InitBitmap (BYTE *pDiData, int cxWinSize, int cyWinSize)
{
	BYTE *dst;
	int x, y, col;

	// initialize the background with gray

	dst = pDiData;
	for (y = 0; y < cyWinSize; y++)
	{
		col = 0;
		for (x = 0; x < cxWinSize; x++)
		{
			// fill with GRAY
			*dst++ = 127;
			*dst++ = 127;
			*dst++ = 127;
			col += 3;
		}
		// rows start on 4 byte boundaries
		while ((col % 4) != 0)
		{
			dst++;
			col++;
		}
	}

}


void FillBitmap(BYTE *pDiData, int cxWinSize, int cyWinSize, PNG_PIXEL* pPngSrc, BOOL bStretched)
{
	BYTE *pStretchedImage;
	BYTE *pImg;
	BYTE *src, *dst;
	BYTE r, g, b, a;
	const int cDIChannels = 3;
	WORD wImgRowBytes;
	WORD wDIRowBytes;
	int cxNewSize, cyNewSize;
	int cxImgPos, cyImgPos;
	int xImg, yImg;
	int xWin, yWin;
	int xOld, yOld;
	int xNew, yNew;


	if(NULL == pPngSrc->pPixel)
		return;



	if (bStretched)
	{
		cxNewSize = cxWinSize - 2 * MARGIN;
		cyNewSize = cyWinSize - 2 * MARGIN;

		// stretch the image to it's window determined size

		// the following two are the same, but the first has side-effects
		// because of rounding
		//      if ((cyNewSize / cxNewSize) > (pPngSrc->nHeight / cxImgSize))
		if ((cyNewSize * pPngSrc->nWidth) > (pPngSrc->nHeight * cxNewSize))
		{
			cyNewSize = cxNewSize * pPngSrc->nHeight / pPngSrc->nWidth;
			cxImgPos = MARGIN;
			cyImgPos = (cyWinSize - cyNewSize) / 2;
		}
		else
		{
			cxNewSize = cyNewSize * pPngSrc->nWidth / pPngSrc->nHeight;
			cyImgPos = MARGIN;
			cxImgPos = (cxWinSize - cxNewSize) / 2;
		}

		pStretchedImage = (BYTE*)malloc (pPngSrc->nChannel * cxNewSize * cyNewSize);
		pImg = pStretchedImage;

		for (yNew = 0; yNew < cyNewSize; yNew++)
		{
			yOld = yNew * pPngSrc->nHeight / cyNewSize;
			for (xNew = 0; xNew < cxNewSize; xNew++)
			{
				xOld = xNew * pPngSrc->nWidth / cxNewSize;

				r = *(pPngSrc->pPixel + pPngSrc->nChannel * ((yOld * pPngSrc->nWidth) + xOld) + 0);
				g = *(pPngSrc->pPixel + pPngSrc->nChannel * ((yOld * pPngSrc->nWidth) + xOld) + 1);
				b = *(pPngSrc->pPixel + pPngSrc->nChannel * ((yOld * pPngSrc->nWidth) + xOld) + 2);

				*pImg++ = r;
				*pImg++ = g;
				*pImg++ = b;

				if (pPngSrc->nChannel == 4)
				{
					a = *(pPngSrc->pPixel + pPngSrc->nChannel * ((yOld * pPngSrc->nWidth) + xOld) + 3);
					*pImg++ = a;
				}
			}
		}

		// calculate row-bytes

		wImgRowBytes = pPngSrc->nChannel * cxNewSize;
		wDIRowBytes = (WORD) ((cDIChannels * cxWinSize + 3L) >> 2) << 2;

		// copy image to screen

		for (yImg = 0, yWin = cyImgPos; yImg < cyNewSize; yImg++, yWin++)
		{
			if (yWin >= cyWinSize - cyImgPos)
				break;
			src = pStretchedImage + yImg * wImgRowBytes;
			dst = pDiData + yWin * wDIRowBytes + cxImgPos * cDIChannels;

			for (xImg = 0, xWin = cxImgPos; xImg < cxNewSize; xImg++, xWin++)
			{
				if (xWin >= cxWinSize - cxImgPos)
					break;
				r = *src++;
				g = *src++;
				b = *src++;
				*dst++ = b; /* note the reverse order */
				*dst++ = g;
				*dst++ = r;
				if (pPngSrc->nChannel == 4)
				{
					a = *src++;
				}
			}
		}

		// free memory

		if (pStretchedImage != NULL)
		{
			free (pStretchedImage);
			pStretchedImage = NULL;
		}

	}

	// process the image not-stretched
	else
	{
		// calculate the central position

		cxImgPos = (cxWinSize - pPngSrc->nWidth) / 2;
		cyImgPos = (cyWinSize - pPngSrc->nHeight) / 2;

		// check for image larger than window

		if (cxImgPos < MARGIN)
			cxImgPos = MARGIN;
		if (cyImgPos < MARGIN)
			cyImgPos = MARGIN;

		// calculate both row-bytes

		wImgRowBytes = pPngSrc->nChannel * pPngSrc->nWidth;
		wDIRowBytes = (WORD) ((cDIChannels * cxWinSize + 3L) >> 2) << 2;

		// copy image to screen

		for (yImg = 0, yWin = cyImgPos; yImg < pPngSrc->nHeight; yImg++, yWin++)
		{
			if (yWin >= cyWinSize - MARGIN)
				break;

			src = pPngSrc->pPixel + yImg * wImgRowBytes;
			dst = pDiData + yWin * wDIRowBytes + cxImgPos * cDIChannels;

			for (xImg = 0, xWin = cxImgPos; xImg < pPngSrc->nWidth; xImg++, xWin++)
			{
				if (xWin >= cxWinSize - MARGIN)
					break;
				r = *src++;
				g = *src++;
				b = *src++;
				*dst++ = b; /* note the reverse order */
				*dst++ = g;
				*dst++ = r;
				if (pPngSrc->nChannel == 4)
				{
					a = *src++;
				}
			}
		}
	}

}



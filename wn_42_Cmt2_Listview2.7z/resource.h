//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by McApi.rc
//
#define IDR_MENU1                       101
#define IDB_BITMAP1                     105
#define IDB_BITMAP2                     106
#define IDD_DIALOG1                     108
#define IDC_LIST_ACCOUNT                1007
#define IDC_ADD                         1008
#define IDC_DEL                         1009
#define IDC_EDIT                        1010
#define IDC_FIND                        1011
#define IDC_NAME                        1012
#define IDC_TEL                         1013
#define IDC_ADDR                        1014
#define IDC_MALE                        1015
#define IDM_ICON                        4000
#define IDM_SMALLICON                   4001
#define IDM_LIST                        4002
#define IDM_REPORT                      4003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         4004
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

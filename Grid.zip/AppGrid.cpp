// Game Client Application
//
////////////////////////////////////////////////////////////////////////////////

#pragma comment(linker, "/subsystem:windows")

#include <windows.h>
#include <stdio.h>

#include "resource.h"

#include "DataGrid.h"

HINSTANCE	m_hInst		;							// Window Instance
char		m_sCls[128]	;							// Window Class Name
char		m_sWin[128]	;							// Window Title
HWND		m_hWnd		;							// Main Window Handle

INT			Create()	;							// Window ����
INT			Run()		;							// Winodw Main Loop �Լ�
void		Cleanup()	;							// ������ ���� �Լ�
LRESULT WINAPI WndProc(HWND,UINT,WPARAM,LPARAM);	// ������ �޽��� ó���Լ�


IDataGrid*	m_pGrid1	;


INT WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, INT)
{
	m_hInst	= GetModuleHandle(NULL);

	if(FAILED(Create()))
		return 0;

	Run();

	return 0;
}



INT Create()
{
	strcpy(m_sCls, "AsycSelect Client");
	m_hWnd = CreateDialog(m_hInst, MAKEINTRESOURCE(IDD_MAIN), NULL, (DLGPROC)WndProc);

	ShowWindow( m_hWnd, SW_SHOW );
	UpdateWindow( m_hWnd );

	return S_OK;
}


void Cleanup()
{
}



INT Run()
{
	MSG		uMsg={0};

	while( uMsg.message!=WM_QUIT )
	{
		Sleep(1);

		if( PeekMessage( &uMsg, NULL, 0U, 0U, PM_REMOVE ) )
		{
			TranslateMessage( &uMsg );
			DispatchMessage( &uMsg );
		}

		else
		{
		}
	}

	DestroyWindow(m_hWnd);

	return 0;
}



LRESULT WINAPI WndProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	static	WPARAM	wParHi;
	static	WPARAM	wParLo;

	wParHi = HIWORD(wParam);
	wParLo = LOWORD(wParam);

	if(WM_INITDIALOG == uMsg)
	{
		INT i =0;
		RECT rc1 = {0,0,300,120};

		LcUtil_CreateDataGrid(NULL, &m_pGrid1, hWnd,  &rc1, 3+1);

		m_pGrid1->SetColumnInfo( 0, "No"		,  40, IDataGrid::DG_CENTER );
		m_pGrid1->SetColumnInfo( 1, "Sock"		,  80, IDataGrid::DG_CENTER );
		m_pGrid1->SetColumnInfo( 2, "ID"		,  80, IDataGrid::DG_CENTER );
		m_pGrid1->SetColumnInfo( 3, "Char"		,  80, IDataGrid::DG_CENTER );

		// Insert DataGrid rows
		for (i=0; i< 2; ++i )
		{
			m_pGrid1->InsertItem( " ", IDataGrid::DG_CENTER );
			m_pGrid1->SetItemInfo(i, 1, "Hello world", 0);
		}
		m_pGrid1->Update();

		return 0;
	}

	else if( WM_COMMAND == uMsg)
	{
		if(IDC_TST_BTN == wParLo)
		{
			m_pGrid1->InsertItem( " ", IDataGrid::DG_CENTER );
			m_pGrid1->SetItemInfo(4, 1, "Hello world", 0);
			m_pGrid1->Update();
		}
	}

	else if(WM_CLOSE == uMsg || WM_DESTROY == uMsg)
	{
		if(m_pGrid1)
		{
			m_pGrid1->Destroy();
			delete m_pGrid1;
			m_pGrid1 = NULL;
		}

		Cleanup();
		PostQuitMessage( 0 );
		return 0;
	}

	else if(WM_SIZE == uMsg)
	{
		if(m_pGrid1)
			m_pGrid1->Resize();
	}

	else if(WM_COMMAND == uMsg)
	{
		if(m_pGrid1 && (HWND)lParam == m_pGrid1->GetWindowHandle())
		{
			if(IDataGrid::DGM_ITEMCHANGED == wParHi)
			{
				char	sTm[32]={0};
				char	sIx[16]={0};
				char	sSc[16]={0};

				INT		row	= m_pGrid1->GetSelectedRow();
			}
		}

		return 0;
	}

	return FALSE;
}

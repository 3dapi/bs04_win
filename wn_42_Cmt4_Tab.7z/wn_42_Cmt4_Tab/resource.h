//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by McApi.rc
//
#define IDB_WORK                        105
#define IDD_WORK                        146
#define IDD_WORK1                       151
#define IDC_WORKTAB                     1014
#define IDC_PTC_TREE                    1020
#define IDC_PTC_TREE_NAME               1021
#define IDC_PTC_TREE_KIND               1022
#define IDC_PTC_TREE_SAVE               1028

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         4004
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

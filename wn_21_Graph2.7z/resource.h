//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by McApi.rc
//
#define IDI_ICON1                       102
#define IDC_CURSOR1                     103
#define IDB_BITMAP1                     106

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40008
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
